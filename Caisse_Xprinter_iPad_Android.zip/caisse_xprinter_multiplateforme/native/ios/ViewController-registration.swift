// Dans la classe BridgeViewController / ViewController qui hérite de CAPBridgeViewController :
override func capacitorDidLoad() {
    bridge?.registerPluginInstance(NetworkPrinterPlugin())
}
