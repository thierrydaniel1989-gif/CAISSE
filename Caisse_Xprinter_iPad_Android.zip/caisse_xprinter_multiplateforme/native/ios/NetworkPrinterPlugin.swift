import Foundation
import Network
import Capacitor

@objc(NetworkPrinterPlugin)
public class NetworkPrinterPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "NetworkPrinterPlugin"
    public let jsName = "NetworkPrinter"
    public let pluginMethods: [CAPPluginMethod] = [
        CAPPluginMethod(name: "print", returnType: CAPPluginReturnPromise)
    ]

    @objc func print(_ call: CAPPluginCall) {
        guard let host = call.getString("host"), !host.isEmpty,
              let portValue = call.getInt("port"), (1...65535).contains(portValue),
              let values = call.getArray("data", Int.self) else {
            call.reject("Paramètres d’impression réseau invalides")
            return
        }

        let data = Data(values.map { UInt8(clamping: $0) })
        let queue = DispatchQueue(label: "caisse.xprinter.network")
        guard let nwPort = NWEndpoint.Port(rawValue: UInt16(portValue)) else {
            call.reject("Port TCP invalide")
            return
        }
        let connection = NWConnection(host: NWEndpoint.Host(host), port: nwPort, using: .tcp)
        var completed = false
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                guard !completed else { return }
                completed = true
                connection.send(content: data, completion: .contentProcessed { error in
                    connection.cancel()
                    if let error = error {
                        call.reject("Échec impression réseau : \(error.localizedDescription)")
                    } else {
                        call.resolve()
                    }
                })
            case .failed(let error):
                guard !completed else { return }
                completed = true
                connection.cancel()
                call.reject("Connexion imprimante impossible : \(error.localizedDescription)")
            default:
                break
            }
        }
        connection.start(queue: queue)
    }
}
